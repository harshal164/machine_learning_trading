"""Analyze a portfolio.

Copyright 2017, Georgia Tech Research Corporation
Atlanta, Georgia 30332-0415
All Rights Reserved
"""

import pandas as pd
import numpy as np
import datetime as dt
from util import get_data, plot_data
import math

# This is the function that will be tested by the autograder
# The student must update this code to properly implement the functionality
def assess_portfolio(sd = dt.datetime(2008,1,1), ed = dt.datetime(2009,1,1), \
    syms = ['GOOG','AAPL','GLD','XOM'], \
    allocs=[0.1,0.2,0.3,0.4], \
    sv=1000000, rfr=0.0, sf=252.0, \
    gen_plot=False):

    # Read in adjusted closing prices for given symbols, date range
    # returns datetime type of list (DateTimeIndex)
    dates = pd.date_range(sd, ed)

    prices_all = get_data(syms, dates)  # automatically adds SPY
    prices = prices_all[syms]  # only portfolio symbols
    # print(prices_all)
    # print("pricesssssssssssssssssssss",prices)
    prices_SPY = prices_all['SPY']  # only SPY, for comparison later

    normalized_prices_SPY=prices_SPY.divide(prices_SPY[0])

    # print("sppppppppppppppy type",type(prices_SPY))
    # print ("normalizeddddddddddd spy",normalized_prices_SPY)
    # Get daily portfolio value
    port_val = prices_SPY # add code here to compute daily portfolio values
    normalized_portfolio=prices.apply(lambda x:x/x[0])
    # print("noramlized ",normalized_portfolio)

    for i in range(len(allocs)):
        normalized_portfolio[syms[i]]=normalized_portfolio[syms[i]].apply(lambda x:x*allocs[i])
    # print("allocated values",normalized_portfolio)

    position_values=normalized_portfolio.apply(lambda x:x*sv)
    # print("final values",position_values)

    total_porfolio_value=position_values.sum(axis=1)
    # print ("sum for all comapny",total_porfolio_value)
    # print ("total values type",type(total_porfolio_value))
    # Get portfolio statistics (note: std_daily_ret = volatility)
    cr, adr, sddr, sr = [0.25, 0.001, 0.0005, 2.1] # add code here to compute stats


    normalized_total_portfolio_value=total_porfolio_value.divide(total_porfolio_value[0])

    cr=total_porfolio_value[-1]/total_porfolio_value[0]-1
    daily_return=total_porfolio_value/total_porfolio_value.shift(1)-1
    # print(daily_return,"daily return")

    adr=daily_return.mean()
    sddr=daily_return.std()
    k=math.sqrt(sf)
    sr=k*(daily_return-rfr).mean()/sddr
    # Compare daily portfolio value with SPY using a normalized plot
    # print("comapare portfolio",compare_portfolio)
    # print "type of compare portfolio",type(compare_portfolio)

    if gen_plot:
        # add code to plot here
        compare_portfolio = pd.concat([normalized_total_portfolio_value, normalized_prices_SPY],
                                      keys=['portfolio', 'spy'], axis=1)

        plot_data(compare_portfolio)

        df_temp = pd.concat([port_val, prices_SPY], keys=['Portfolio', 'SPY'], axis=1)
        pass

    # Add code here to properly compute end value
    ev = sv

    return cr, adr, sddr, sr, ev

def test_code():
    # This code WILL NOT be tested by the auto grader
    # It is only here to help you set up and test your code

    # Define input parameters
    # Note that ALL of these values will be set to different values by
    # the autograder!
    start_date = dt.datetime(2010,1,1)
    end_date = dt.datetime(2010,12,31)
    symbols = ['GOOG', 'AAPL', 'GLD', 'XOM']
    allocations = [0.2, 0.3, 0.4, 0.1]
    start_val = 1000000  
    risk_free_rate = 0.0
    sample_freq = 252

    # Assess the portfolio
    cr, adr, sddr, sr, ev = assess_portfolio(sd = start_date, ed = end_date,\
        syms = symbols, \
        allocs = allocations,\
        sv = start_val, \
        gen_plot = True)

    # Print statistics
    print "Start Date:", start_date
    print "End Date:", end_date
    print "Symbols:", symbols
    print "Allocations:", allocations
    print "Sharpe Ratio:", sr
    print "Volatility (stdev of daily returns):", sddr
    print "Average Daily Return:", adr
    print "Cumulative Return:", cr

if __name__ == "__main__":
    test_code()
